<?php
 $matricula = $_POST["matricula"]; //captura o nome
 echo $matricula; //exibe a matricula concatenada
?>